 
import java.util.Scanner;
import java.util.TreeMap;

/**
 * Clase principal de la estructura de datos, contiene un TreeMap (Arbol rojo-negro) y sus Métodos principales
 * (buscar por nombre, buscar por ruta e insertar).
 * Esta clase fue realizada con la colaboracion de Luis Javier Palacios, Alejandro Cano y Jorge Luis Herrera.
 * 
 * @author Santiago Escobar, Sebastian Giraldo y Luisa Maria Vasquez.
 * @version 29/10/2017
 */
public class Arbol {
    
    /**
     * TreeMap de java basado en arboles rojo-negro.
     */
    static TreeMap<String, TreeMap<String, Archivo>> tmap = new TreeMap<>();

    /**
     * Método que inserta un archivo (ya sea fichero o directorio) a la estructura de datos, 
     * en caso de que ya exista un archivo con su nombre, lo agrega al arbol auxiliar que maneja colisiones.
     * @param v Archivo a ser insertado en la estructura de datos. 
     */
    public static void add(Archivo v) {
        if (tmap.get(v.getNombre()) == null) {
            TreeMap<String, Archivo> tmap2 = new TreeMap<>();
            tmap2.put(v.getRuta(), v);
            tmap.put(v.getNombre(), tmap2);
        } else {
            tmap.get(v.getNombre()).put(v.getRuta(), v);
        }
    }
    
    /**
     * Método que retorna un directorio buscando por su ruta, sirve como auxiliar al Método "buscar por ruta".
     * @param r Ruta del directorio buscado.
     * @return Directorio buscado(objeto).
     */
    public static Directorio buscarPorRutaLeer(String r) {
        String[] a = r.split("/");
        TreeMap t = tmap.get(a[a.length - 1]);
        if (t == null) {
        } else {
            if (t.size() == 1) {
                Directorio e = (Directorio) t.firstEntry().getValue();
                return e;
            } else {
                return (Directorio) t.get(r);

            }
        }
        return null;
    }

    /**
     * Método que busca los archivos existentes en una ruta especifica y da la opcion al usuario de listarlos
     * advitiendole del aumento de complejidad en el Método.
     * @param r Ruta buscada.
     */
    public static void buscarPorRuta(String r) {
        String[] a = r.split("/");
        TreeMap t = tmap.get(a[a.length - 1]);
        if (t == null) {
            System.out.println("");
            System.out.println("No existen archivos en esta ruta");
        } else {
            if (t.size() == 1) {
                System.out.println("");
                System.out.println("El archivo " + a[a.length - 1] + " existe en:");
                Archivo e = (Archivo) t.firstEntry().getValue();
                System.out.println(e.getRuta());

                if (e instanceof Directorio) {
                    System.out.println("Ingrese 1 si desea listar o ingrese otro número de no ser así, es O(n)");
                    Scanner sc = new Scanner(System.in);
                    int aa = sc.nextInt();
                    if (aa == 1) {
                        ((Directorio) e).listar();
                    }
                }
            } else {
                Archivo ar = (Directorio) t.get(r);
                if (ar != null) {
                    System.out.println("El archivo " + a[a.length - 1] + " existe en:");
                    System.out.println(ar.getRuta());
                    if (ar instanceof Directorio) {
                        System.out.println("Ingrese 1 si desea listar o ingrese otro número de no ser así, es O(n)");
                        Scanner sc = new Scanner(System.in);
                        int aa = sc.nextInt();
                        if (aa == 1) {
                            ((Directorio) ar).listar();
                        }
                    }
                }
            }
        }

    }

    /**
     * Método que busca si un archivo existe o no en la estructura de datos y en caso de ser un directorio le da la opcion
     * al usuario de listar su contenido advirtiendole del aumento de complejidad del algoritmo.
     * @param name Nombre del archivo buscado.
     */
    public static void buscar(String name) {

        TreeMap t = tmap.get(name);
        if (t == null) {
            System.out.println("");
            System.out.println("El archivo no existe");
        } else {
            if (t.size() == 1) {
                System.out.println("");
                System.out.println("El archivo " + name + " existe en:");
                Archivo e = (Archivo) t.firstEntry().getValue();
                System.out.println(e.getRuta());

                if (e instanceof Directorio) {
                    System.out.println("Ingrese 1 si desea listar o ingrese otro número de no ser así, es O(n)");
                    Scanner sc = new Scanner(System.in);
                    int a = sc.nextInt();
                    if (a == 1) {
                        ((Directorio) e).listar();
                    }

                }
            } else {
                Archivo e = (Archivo) t.firstEntry().getValue();
                System.out.println(e.getRuta());

                System.out.println("Existen varios archivos con este nombre , ingrese 1 si quiere listar las rutas de estos, es O(n) ");

                Scanner sc = new Scanner(System.in);
                int a = sc.nextInt();
                if (a == 1) {
                    Object[] ar = t.values().toArray();
                    for (Object ar1 : ar) {
                        System.out.println(((Archivo) ar1).getRuta());
                    }
                }

            }
        }
    }

}

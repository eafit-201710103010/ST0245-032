
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Stack;

/**
 * Clase que se encarga de leer el archivo de texto ingresado y de ingresarlo en la estructura de datos.
 * Esta clase fue realizada con la colaboracion de Luis Javier Palacios, Alejandro Cano y Jorge Luis Herrera. 
 *
 * @author Santiago Escobar , Sebastian Giraldo y Luisa Maria Vasquez.
 * @version 29/10/2017
 */
public class TestLeer {

    /**
     * Metodo que lee un archivo especifico y, basado en este, saca los satos de cada fichero o directorio y los
     * añade a la estructura de datos; para esto, lee linea por linea el archivo, saca sus componentes por
     * medio del metodo "split" y crea un objeto con estos, para diferenciar a que directorio padre pertenece
     * analiza la diferencia en cantidad de espacios  respecto al leido anteriormente y de acuerdo a esto le 
     * asigna una ruta y lo añade como hijo al directorio padre.
     */
    public static void leer() {
        Directorio l = null;
        LinkedList<String> datos = new LinkedList<>();
        try {
            FileInputStream fstream = new FileInputStream(new File("Datos2.txt"));
            InputStreamReader Fichero = new InputStreamReader(fstream, "Unicode");
            BufferedReader br = new BufferedReader(Fichero);

            String linea;
            int nactual = 0;
            int nanterior = 0;
            LinkedList<String> ruta = new LinkedList<>();
            int c = 0;
            while ((linea = br.readLine()) != null) {
                datos.add(linea);
                if (c > 0) { 
                    String[] a = datos.get(c).split("─ ");
                    String[] b = datos.get(c).split("]");
                    String[] cc = separarLinea(datos.get(c));//Arreglo con los datos del archivo
                    int spaces = a[0].length();
                    String r;
                    if (spaces > nanterior) {
                        nanterior = spaces;
                       Arbol.buscarPorRutaLeer(sacarRuta(ruta)).agregarArchivo(cc[2]);
                        ruta.add(cc[2]);
                        r = sacarRuta(ruta);
                    } else if (spaces < nanterior) {
                        
                        nanterior -= 4;
                        for (int i = nanterior; i >= spaces; i -= 4) {
                            ruta.removeLast();
                        }       
                        ruta.removeLast();
                        Arbol.buscarPorRutaLeer(sacarRuta(ruta)).agregarArchivo(cc[2]);
                        ruta.add(cc[2]);
                        r = sacarRuta(ruta);
                    } else { 
                        ruta.removeLast();
                        Arbol.buscarPorRutaLeer(sacarRuta(ruta)).agregarArchivo(cc[2]);
                        nanterior = spaces;
                        ruta.add(cc[2]);
                        r = sacarRuta(ruta);
                    }
                     if(linea.contains("4.0K")){
                        Directorio dir = new Directorio(cc[2],cc[1],cc[0],r);
                        Arbol.add(dir);
                    }else{
                        Fichero dir = new Fichero(cc[2],cc[1],cc[0],r);
                        Arbol.add(dir);
                        
                    }

                } else if (c == 0) {

                    String aux = datos.get(0);
                    aux = aux.substring(0, aux.length() - 1);
                    Directorio dir = new Directorio(aux, "", "", "");
                    ruta.add(aux);
                    Arbol.add(dir);
                }
                c++;
            }
        } catch (Exception e) {

        }
    }

    /**
     * Metodo que divide cada linea en sus componentes para tener un arreglo que contenga
     * los datos de cada fichero/directorio
     * @param g Linea a ser dividida
     * @return Arreglo que contiene los datos de cada fichero/directorio
     */
    public static String[] separarLinea(String g) {
        String p[] = g.split("─");
        p[2] = p[2].substring(2);
        String p2[] = p[2].split("]");
        String p3[] = p2[0].split(" ");
        String p4[] = new String[3];
        if (p3.length > 2) { //En caso de que haya problemas para sacar el peso
            p2[1] = p2[1].substring(2);
            p4[0] = p3[0];
            p4[1] = p3[2];
            p4[2] = p2[1];
        } else {
            p2[1] = p2[1].substring(2);
            p4[0] = p3[0];
            p4[1] = p3[1];
            p4[2] = p2[1];
        }

        return p4;
    }


    /**
     * Metodo que junta los componentes de una ruta en un solo String.
     * @param ruta Lista enlazada con los componentes de la ruta.
     * @return Ruta como un String.
     */
    private static String sacarRuta(LinkedList<String> ruta) {
        String r = "";
        for (int i = 0; i < ruta.size(); i++) {
            r = r.concat(ruta.get(i).concat("/"));
        }
        return r;
    }

}

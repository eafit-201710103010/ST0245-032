import java.util.LinkedList;

/**
 * Clase abstracta que representa de manera general los elementos que se encuentran en la estructura de datos. 
 * @author Santiago Escobar , Sebastian Giraldo y Luisa Maria Vasquez.
 * @version 29/10/2017
 */
public class Archivo {
    /**
     * Usuario creador del archivo.
     */
    String autor;
    /**
     * Peso del archivo.
     */
    String peso;
    /**
     * Nombre del archivo.
     */
    String nombre;
    /**
     * Ruta en la que se encuentra el archivo.
     */
    String ruta;
    /**
     * Metodo que retorna la ruta en la que sencuentra el archivo.
     * @return Ruta en la que se encuentra el archivo.
     */ 
    public String getRuta() {
        return ruta;
    }

    /**
     * Metodo cambia la ruta del archivo.
     * @param ruta Nueva ruta del archivo.
     */
    public void setRuta(String ruta) {
        this.ruta = ruta;
    }
   
    /**
     * Constructor de la clase archivo.
     * @param nombre Nombre del nuevo archivo.
     * @param ruta Ruta del nuevo archivo.
     * @return Archivo creado.
     */
    public Archivo(String nombre,String ruta) {
       
        this.nombre = nombre;
        this.ruta=ruta;
    }

    /**
     * Metodo que retorna el autor del archivo.
     * @return Autor del archivo.
     */ 
    public String getAutor() {
        return autor;
    }

    /**
     * Metodo cambia el autor  del archivo.
     * @param autor Nuevo autor del archivo.
     */
    public void setAutor(String autor) {
        this.autor = autor;
    }

    /**
     * Metodo que retorna el peso del archivo.
     * @return Peso del archivo.
     */ 
    public String getPeso() {
        return peso;
    }

    /**
     * Metodo cambia el peso del archivo.
     * @param peso Nuevo peso del archivo.
     */
    public void setPeso(String peso) {
        this.peso = peso;
    }

    /**
     * Metodo que retorna el nombre del archivo.
     * @return Nombre del archivo.
     */ 
    public String getNombre() {
        return nombre;
    }

    
    /**
     * Metodo cambia el nombre del archivo.
     * @param nombre Nuevo nombre del archivo.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
}

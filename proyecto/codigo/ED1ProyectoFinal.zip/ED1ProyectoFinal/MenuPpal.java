import java.util.*;

/**
 * Clase que contiene los métodos que interactuan con el usuario.
 *
 * @author Santiago Escobar, Sebastian Giraldo y Luisa Maria Vasquez. 
 * @version 29/10/2017
 */
public class MenuPpal {

    /**
     * Método principal que llama a la lactura del archivo y dirige al usuario al menu.
     * 
     */
    public static void main(String[] args) {
        System.out.println("Bienvenido, procederemos a la lectura de los archivos ya existentes");
        TestLeer.leer();
        Arbol t = new Arbol();
        menu(t);
    }

    /**
     * Método que presenta al usuario las diferentes opciones para manejar la estructura de datos.
     * @param t TreeMap que representa la estructura de datos. 
     * 
     */
    public static void menu(Arbol t) {

        System.out.println("");
        System.out.println("Digite el numero de la opcion que desea realizar");
        System.out.println("1. Insertar directorio");
        System.out.println("2. Insertar fichero");
        System.out.println("3. Buscar directorio o fichero");
        System.out.println("4. Buscar por ruta");
        System.out.println("5. Finalizar");
        System.out.println("");
        int opcion;
        try {
            Scanner src = new Scanner(System.in);
            opcion = src.nextInt();
            src.nextLine();
            switch (opcion) {
                case 1:
                    insertarD(t);
                    break;

                case 2:
                    insertarF(t);
                    break;

                case 3:
                    buscar(t);
                    break;

                case 4:
                    System.out.println("Ingrese la ruta: ");
                    Arbol.buscarPorRuta(src.nextLine());
                    menu(t);
                    break;

                case 5:
                    return;

                default:
                    System.out.println("Por favor digita una opcion valida");

            }
        } catch (Exception e) {
            System.out.println("Por favor digita una opcion valida");
        }

    }

    /**
     * Método que recibe los datos del directorio a insertar y llama al método "insertar" de la estructura de datos.
     * @param t TreeMap que representa la estructura de datos. 
     */
    public static void insertarD(Arbol t) {
        try {
            Scanner src = new Scanner(System.in);
            String nombre;
            String autor;
            String ruta;
            String peso;
            System.out.println("");
            System.out.println("Ingresa el nombre del directorio: ");
            nombre = src.next();
            System.out.println("Ingresa el autor del directorio: ");
            autor = src.next();
            System.out.println("Ingresa el peso del directorio: ");
            peso = src.next();
            System.out.println("Ingresa la ruta en la que se encuentra el directorio: ");
            ruta = src.next();

            Directorio nuevo = new Directorio(nombre, peso, autor, ruta);
            Arbol.add(nuevo);
            System.out.println("");
            System.out.println("Proceso finalizado exitosamente");
            menu(t);
        } catch (Exception e) {
            System.out.println("Encontramos un error con los datos ingresados , intentalo de nuevo");
            menu(t);
        }
    }

    /**
     * Método que recibe los datos del fichero a insertar y llama al método "insertar" de la estructura de datos.
     * @param t TreeMap que representa la estructura de datos. 
     */
    public static void insertarF(Arbol t) {
        try {
            Scanner src = new Scanner(System.in);
            String nombre;
            String autor;
            String ruta;
            String peso;
            System.out.println("Ingresa el nombre del fichero: ");
            nombre = src.nextLine();
            System.out.println("Ingresa el autor del fichero: ");
            autor = src.nextLine();
            System.out.println("Ingresa el peso del fichero: ");
            peso = src.nextLine();
            System.out.println("Ingresa la ruta en la que se encuentra el fichero: ");
            ruta = src.nextLine();

            Fichero nuevo = new Fichero(nombre, peso, autor, ruta);
            Arbol.add(nuevo);
            System.out.println("");
            System.out.println("Proceso finalizado exitosamente");
            menu(t);
        } catch (Exception e) {
            System.out.println("Encontramos un error con los datos ingresados , intentalo de nuevo");
            menu(t);
        }
    }
    
    /** 
     * Método que recibe el nombre del directorio o fichero a buscar y llama al método "buscar" de la estructura de datos.
     * @param t TreeMap que representa la estructura de datos. 
     */
    public static void buscar(Arbol t) {

        try {
            Scanner src = new Scanner(System.in);
            String nombre;
            System.out.println("Ingresa el nombre del directorio o fichero a buscar : ");
            nombre = src.nextLine();
            Arbol.buscar(nombre);
            System.out.println("");
            System.out.println("Proceso finalizado exitosamente");
            menu(t);
        } catch (Exception e) {
            System.out.println("Encontramos un error con los datos ingresados , intentalo de nuevo");
            menu(t);
        }
    }
}

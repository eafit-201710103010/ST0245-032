
import java.util.LinkedList;

/**
 * Clase que representa los directorios en la estructura de datos. 
 * @author Santiago Escobar, Sebastian Giraldo y Luisa Maria Vasquez.
 * @version 29/10/2017
 */
public class Directorio extends Archivo {
    /**
     * Lista del nombre los archivos contenidos en el directorio.
     */
    LinkedList<String> l = new LinkedList<>();

    /**
     * Constructor de directorio.
     * @param nombre Nombre del directorio.
     * @param peso Peso del directorio.
     * @param autor Usuario creador del directorio.
     * @param ruta Ruta en la que se encuentra el directorio.
     * @return Directorio creado.
     */
    public Directorio(String nombre, String peso, String autor,String ruta) {
        super(nombre,ruta);
        this.autor = autor;
        this.peso = peso;
    }

    /**
     * Metodo que agrega el nombre de un archivo a la lista de contenidos del directorio.
     * @param a Nombre del archivo a agregar.
     */
    public void agregarArchivo(String a) {
        l.addLast(a);
    }
    
    /**
     * Metodo que muestra el nombre de todos los archivos que contiene el directorio.
     */
    public void listar(){
        System.out.println("Ficheros existentes en: "+nombre);
        for (int i = 0; i < l.size(); i++) {
            System.out.println(l.get(i));
        }
    }
}

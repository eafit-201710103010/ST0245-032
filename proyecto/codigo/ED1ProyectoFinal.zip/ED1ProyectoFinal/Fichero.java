
/**
 * Clase que representa los ficheros que se encuentran en la estrcutura de datos.
 * 
 * @author Santiago Escobar, Sebastian Giraldo y Luisa Maria Vasquez.
 * @version 29/20/2017
 */
public class Fichero extends Archivo {
    
    /**
     * Constructor de la clase fichero.
     * @param nombre Nombre del fichero.
     * @param peso Pero del fichero.
     * @param autor Usuario creador del fichero. 
     * @param ruta Ruta en la que se encuentra el fichero.
     * @return Fichero creado.
     */
     public Fichero(String nombre, String peso, String autor,String ruta) {
        super(nombre,ruta);
        this.autor = autor;
        this.peso = peso;
    }

}
